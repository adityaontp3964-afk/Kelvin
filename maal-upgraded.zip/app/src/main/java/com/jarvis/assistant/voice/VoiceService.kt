package com.jarvis.assistant.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.ai.AiClient
import com.jarvis.assistant.command.ActionStatus
import com.jarvis.assistant.command.CommandDispatcher
import com.jarvis.assistant.command.Cmd
import com.jarvis.assistant.command.PermissionManager
import com.jarvis.assistant.command.CommandParser
import com.jarvis.assistant.command.CommandResult
import com.jarvis.assistant.command.WakeMatcher
import com.jarvis.assistant.data.AssistantState
import com.jarvis.assistant.data.AutoListen
import com.jarvis.assistant.data.FeedbackMode
import com.jarvis.assistant.data.HistoryItem
import com.jarvis.assistant.data.Level
import com.jarvis.assistant.data.NoiseMode
import com.jarvis.assistant.data.Prefs
import com.jarvis.assistant.data.RecogMode
import com.jarvis.assistant.data.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.android.RecognitionListener
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Voice session: WAKE WORD -> GREETING -> LISTEN -> RECOGNIZE -> UNDERSTAND -> CONFIRM -> EXECUTE -> SPEAK -> RESUME.
 * Wake-word detection is always local (Vosk). Commands use Online (Android SpeechRecognizer), Offline (Vosk) or Automatic.
 * Exactly one microphone session exists at a time; the mic is released before every spoken reply.
 */
class VoiceService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var app: JarvisApp
    private lateinit var engine: VoskEngine
    private lateinit var online: OnlineRecognizer
    private lateinit var tts: Tts
    private lateinit var dispatcher: CommandDispatcher

    private var running = false
    private var wakeMode = true
    private var testing = false
    private var cmdModel: Model? = null
    private var wakeModel: Model? = null
    private var sessionId = 0
    private val handled = AtomicBoolean(false)
    private var lastPartial = ""
    private var onlineBlockedUntil = 0L      // after an online failure, AUTO mode stays offline for a minute (no flapping)
    private val turns = ArrayDeque<Pair<String, String>>()
    private val main = Handler(Looper.getMainLooper())
    private val segments = ArrayList<String>()          // finished utterance pieces of the current offline command
    private var finalizer: Runnable? = null             // fires when the pause after the last piece is long enough
    private var conversationWindow = false              // listening again for a follow-up (shorter timeout)
    private var lastErrorSpoken = ""
    private var lastErrorAt = 0L
    private var ackJob: Job? = null

    companion object {
        const val ACTION_START = "com.jarvis.assistant.START"
        const val ACTION_PTT = "com.jarvis.assistant.PTT"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        const val ACTION_TEST_WAKE = "com.jarvis.assistant.TEST_WAKE"
        private const val CHANNEL = "jarvis_voice"   // id kept so existing installs keep their channel settings
        private const val NOTIF_ID = 42
        private const val ONLINE_COOLDOWN_MS = 60_000L

        fun start(ctx: Context, pushToTalk: Boolean) {
            val i = Intent(ctx, VoiceService::class.java).setAction(if (pushToTalk) ACTION_PTT else ACTION_START)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun testWake(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, VoiceService::class.java).setAction(ACTION_TEST_WAKE))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, VoiceService::class.java).setAction(ACTION_STOP))
        }
    }

    override fun onCreate() {
        super.onCreate()
        app = application as JarvisApp
        engine = VoskEngine(this)
        online = OnlineRecognizer(this)
        tts = Tts(this)
        dispatcher = CommandDispatcher(this, app)
        dispatcher.progress = { msg -> if (app.settings.prefs.value.feedbackMode != FeedbackMode.OFF) AssistantState.response.value = msg }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "FRIDAY voice session", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> shutdown(VoiceState.STOPPED)
            ACTION_PTT -> begin(pushToTalk = true)
            ACTION_TEST_WAKE -> beginWakeTest()
            else -> begin(pushToTalk = false)
        }
        return START_NOT_STICKY   // a mic foreground service cannot be silently restarted from the background on Android 14+
    }

    override fun onDestroy() {
        running = false
        cancelFinalizer()
        online.cancel()
        engine.release()
        tts.shutdown()
        scope.cancel()
        if (AssistantState.state.value != VoiceState.ERROR) AssistantState.state.value = VoiceState.STOPPED
        super.onDestroy()
    }

    private fun prefs(): Prefs = app.settings.prefs.value
    private fun ttsOpts(p: Prefs) = TtsOptions(p.ttsVoice, p.ttsRate, p.ttsPitch)

    // ---- lifecycle ----

    private fun begin(pushToTalk: Boolean) {
        val ptt = pushToTalk || !prefs().wakeEnabled   // wake word switched off in Settings: never listen for it
        if (running) {
            // Never open a second mic session; only allow switching from wake-wait to push-to-talk.
            if (ptt && !testing && AssistantState.state.value == VoiceState.WAITING_FOR_WAKE_WORD) {
                sessionId++
                engine.stop()
                listenCommand()
            }
            return
        }
        if (!startForegroundSafely()) return
        if (!PermissionManager.mic(this)) {
            // revoked in system settings while the app was closed: stop cleanly instead of crashing in AudioRecord
            AssistantState.error.value = "Microphone permission nahi hai. Settings > Permissions mein dijiye."
            shutdown(VoiceState.ERROR)
            return
        }
        running = true
        testing = false
        conversationWindow = false
        wakeMode = !ptt
        AssistantState.error.value = null
        AssistantState.heard.value = ""
        AssistantState.state.value = VoiceState.INITIALIZING
        scope.launch {
            val p = prefs()
            val problem = withContext(Dispatchers.IO) { loadModels(p) }
            if (!running) return@launch
            if (problem != null) { fail(problem); return@launch }
            if (p.aiEnabled && p.aiEndpoint.isNotBlank()) app.scope.launch { AiClient.warmUp(p.aiEndpoint) }
            if (wakeMode) enterWake() else listenCommand()
        }
    }

    /** Loads only the offline models the current settings need. Returns an error message, or null if ready. Blocking. */
    private fun loadModels(p: Prefs): String? {
        try {
            wakeModel = when {
                !wakeMode -> null
                p.voskLang() == "en" -> engine.model("en")
                else -> engine.model("en") ?: engine.model(p.voskLang())
            }
            cmdModel = if (p.recogMode == RecogMode.ONLINE) null else engine.model(p.voskLang())
        } catch (t: Throwable) {
            return "Voice model load nahi hua: ${t.message}"
        }
        if (wakeMode && wakeModel == null)
            return "Wake word ke liye offline voice model chahiye. Settings > Voice models se download kijiye, ya PUSH TO TALK use kijiye."
        return when (p.recogMode) {
            RecogMode.OFFLINE ->
                if (cmdModel == null) "Offline mode ke liye voice model (${p.voskLang()}) nahi mila. Settings > Voice models se download kijiye." else null
            RecogMode.ONLINE ->
                if (!OnlineRecognizer.isAvailable(this)) "Is phone par online speech recognition service nahi hai. Offline ya Automatic mode chuniye." else null
            RecogMode.AUTO ->
                if (cmdModel == null && !OnlineRecognizer.isAvailable(this))
                    "Na online recognition available hai na offline model installed hai. Settings > Voice models se model download kijiye." else null
        }
    }

    /** Foreground service must start within seconds of startForegroundService(); returns false (and stops) on failure. */
    private fun startForegroundSafely(): Boolean {
        return try { startFg(); true } catch (e: Exception) {
            AssistantState.error.value = "Foreground service start nahi hua: ${e.message}"
            AssistantState.state.value = VoiceState.ERROR
            stopSelf()
            false
        }
    }

    private fun startFg() {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("FRIDAY microphone active")
            .setContentText("Sun raha hoon. Band karne ke liye Stop dabaiye.")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "STOP", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIF_ID, n)
    }

    private fun shutdown(finalState: VoiceState) {
        running = false
        testing = false
        sessionId++
        cancelFinalizer()
        ackJob?.cancel()
        engine.stop()
        online.cancel()
        tts.stop()
        dispatcher.cancelPending()
        conversationWindow = false
        AssistantState.state.value = finalState
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun fail(message: String) {
        AssistantState.error.value = message
        shutdown(VoiceState.ERROR)
    }

    // ---- wake word ----

    private fun parseJson(h: String?, key: String): String =
        try { JSONObject(h ?: "{}").optString(key, "").trim() } catch (e: Exception) { "" }

    private fun enterWake() {
        if (!running) return
        val m = wakeModel ?: return fail("Wake model load nahi hua")
        AssistantState.state.value = VoiceState.WAITING_FOR_WAKE_WORD
        val id = ++sessionId
        val fired = AtomicBoolean(false)
        fun check(text: String, final: Boolean) {
            if (id != sessionId || text.isEmpty()) return
            val pp = prefs()
            // LOW wake sensitivity ignores unfinished (partial) guesses: fewer accidental activations
            if (!final && pp.wakeSensitivity == Level.LOW) return
            if (WakeMatcher.matches(text, pp.wakePhrase, pp.wakeSensitivity) && fired.compareAndSet(false, true)) {
                engine.stop()
                onWake()
            }
        }
        try {
            engine.listen(m, 0, object : RecognitionListener {
                override fun onPartialResult(h: String?) = check(parseJson(h, "partial"), false)
                override fun onResult(h: String?) = check(parseJson(h, "text"), true)
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) { if (id == sessionId) fail("Mic error: ${e?.message}") }
                override fun onTimeout() {}
            })
        } catch (e: Exception) { fail("Microphone shuru nahi hua: ${e.message}") }
    }

    /** Settings > Test wake word: listens for ten seconds and reports whether the phrase was heard. */
    private fun beginWakeTest() {
        if (running) {
            AssistantState.wakeTest.value = "Pehle chalta hua session STOP kijiye, phir test kijiye."
            return
        }
        if (!startForegroundSafely()) { AssistantState.wakeTest.value = "Test shuru nahi hua."; return }
        running = true
        testing = true
        wakeMode = true
        val p = prefs()
        AssistantState.error.value = null
        AssistantState.heard.value = ""
        AssistantState.state.value = VoiceState.INITIALIZING
        AssistantState.wakeTest.value = "Model load ho raha hai..."
        scope.launch {
            val m = withContext(Dispatchers.IO) {
                try { if (p.voskLang() == "en") engine.model("en") else (engine.model("en") ?: engine.model(p.voskLang())) }
                catch (t: Throwable) { null }
            }
            if (!running) return@launch
            if (m == null) { finishWakeTest("Offline voice model nahi mila. Pehle Voice models se download kijiye."); return@launch }
            runWakeTest(m, p.wakePhrase, p.wakeSensitivity)
        }
    }

    private fun runWakeTest(m: Model, phrase: String, sens: Level) {
        AssistantState.state.value = VoiceState.WAITING_FOR_WAKE_WORD
        AssistantState.wakeTest.value = "Ab boliye: \"$phrase\" (10 second)"
        val id = ++sessionId
        val finished = AtomicBoolean(false)
        fun check(text: String) {
            if (id != sessionId || text.isEmpty()) return
            AssistantState.heard.value = text
            if (WakeMatcher.matches(text, phrase, sens) && finished.compareAndSet(false, true))
                finishWakeTest("DETECTED: wake phrase suna gaya (\"$text\").")
        }
        try {
            engine.listen(m, 10000, object : RecognitionListener {
                override fun onPartialResult(h: String?) = check(parseJson(h, "partial"))
                override fun onResult(h: String?) = check(parseJson(h, "text"))
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) {
                    if (id == sessionId && finished.compareAndSet(false, true)) finishWakeTest("Mic error: ${e?.message}")
                }
                override fun onTimeout() {
                    if (id != sessionId || !finished.compareAndSet(false, true)) return
                    val heard = AssistantState.heard.value
                    finishWakeTest(
                        if (heard.isBlank()) "NOT DETECTED: kuch suna nahi gaya. Mic aur model check kijiye."
                        else "NOT DETECTED: model ne \"$heard\" suna. Shayad ye phrase model pehchaan nahi pa raha; doosra phrase try kijiye."
                    )
                }
            })
        } catch (e: Exception) { finishWakeTest("Microphone shuru nahi hua: ${e.message}") }
    }

    private fun finishWakeTest(message: String) {
        AssistantState.wakeTest.value = message
        shutdown(VoiceState.STOPPED)
    }

    private fun onWake() {
        if (!running) return
        val p = prefs()
        val who = p.userName.ifBlank { "boss" }
        val greeting = p.greeting.ifBlank { "Haan $who, boliye. Main sun raha hoon." }
        AssistantState.response.value = greeting
        AssistantState.responseSource.value = "LOCAL"
        if (!p.voiceReplies) { listenCommand(); return }
        AssistantState.state.value = VoiceState.SPEAKING
        tts.speak(greeting, p.ttsLang, ttsOpts(p)) { if (running) listenCommand() }
    }

    // ---- command recognition (Online / Offline / Automatic) ----

    private fun cancelFinalizer() { finalizer?.let { main.removeCallbacks(it) }; finalizer = null }

    private fun listenCommand() {
        if (!running) return
        if (!PermissionManager.mic(this)) { fail("Microphone permission nahi hai. Settings > Permissions mein dijiye."); return }
        AssistantState.state.value =
            if (dispatcher.expectsFollowUp) VoiceState.AWAITING_CONFIRMATION else VoiceState.LISTENING
        AssistantState.heard.value = ""
        lastPartial = ""
        segments.clear()
        cancelFinalizer()
        handled.set(false)
        val p = prefs()
        val useOnline = when (p.recogMode) {
            RecogMode.ONLINE -> true
            RecogMode.OFFLINE -> false
            RecogMode.AUTO -> System.currentTimeMillis() >= onlineBlockedUntil &&
                OnlineRecognizer.hasInternet(this) && OnlineRecognizer.isAvailable(this)
        }
        // a follow-up window is short; an answer the assistant asked for gets the full timeout
        val timeoutMs = p.listenTimeoutSec * 1000L
        val limit = if (conversationWindow && !dispatcher.expectsFollowUp) minOf(timeoutMs, 8000L) else timeoutMs
        when {
            useOnline -> listenOnline(p, limit, fallbackAllowed = p.recogMode == RecogMode.AUTO && cmdModel != null)
            cmdModel != null -> listenOffline(p, limit, if (p.recogMode == RecogMode.AUTO) "OFFLINE (AUTO)" else "OFFLINE")
            else -> recognitionUnavailable("Internet nahi hai aur offline voice model bhi installed nahi hai. Settings > Voice models se model download kijiye.")
        }
    }

    private fun listenOnline(p: Prefs, limitMs: Long, fallbackAllowed: Boolean) {
        engine.stop()   // release the Vosk microphone before SpeechRecognizer opens it
        val id = ++sessionId
        AssistantState.recogEngine.value = "ONLINE"
        val options = OnlineRecognizer.Options(
            languageTag = p.speechTag(),
            extraLanguages = p.extraSpeechLangs(),
            maxResults = if (p.noiseMode == NoiseMode.NOISY) 5 else 3,
            silenceMs = p.pauseMs(),
            timeoutMs = limitMs
        )
        online.start(options, object : OnlineRecognizer.Listener {
            override fun onPartial(text: String) {
                if (id != sessionId) return
                lastPartial = text
                AssistantState.heard.value = text
            }
            override fun onFinal(text: String, alternatives: List<String>, confidence: Float) {
                if (id == sessionId) acceptResult(text, alternatives, confidence)
            }
            override fun onNoSpeech() {
                if (id != sessionId) return
                if (lastPartial.isNotEmpty()) acceptResult(lastPartial, listOf(lastPartial), -1f)
                else { dispatcher.cancelPending(); resume() }
            }
            override fun onFailure(kind: OnlineFailure, message: String) {
                if (id != sessionId) return
                if (kind == OnlineFailure.SERVICE_UNAVAILABLE) onlineBlockedUntil = System.currentTimeMillis() + ONLINE_COOLDOWN_MS
                if (fallbackAllowed && kind == OnlineFailure.SERVICE_UNAVAILABLE && cmdModel != null) {
                    // One fallback per utterance; the offline attempt never switches back to online.
                    AssistantState.error.value = "Online recognition fail ($message); offline engine use ho raha hai."
                    listenOffline(p, limitMs, "OFFLINE (FALLBACK)")
                } else recognitionUnavailable(message)
            }
        })
    }

    /**
     * Offline (Vosk) recognition. Vosk ends an utterance after a short silence; to avoid cutting the user off during a
     * natural pause, finished pieces are collected and the command is only executed after the extra pause tolerance
     * from Settings has passed without new speech. Short answers (yes / no / stop) are executed immediately.
     */
    private fun listenOffline(p: Prefs, limitMs: Long, label: String) {
        val m = cmdModel ?: return recognitionUnavailable("Offline voice model load nahi hua.")
        online.cancel()
        AssistantState.recogEngine.value = label
        val id = ++sessionId
        segments.clear()
        lastPartial = ""
        cancelFinalizer()
        fun collected(): String =
            (segments + (if (lastPartial.isNotEmpty()) listOf(lastPartial) else emptyList())).joinToString(" ").trim()
        fun finishNow() {
            cancelFinalizer()
            if (id != sessionId) return
            val t = collected()
            if (t.isEmpty()) { dispatcher.cancelPending(); resume() } else acceptResult(t, listOf(t), -1f)
        }
        val extraPause = (p.pauseMs() - 1000).coerceAtLeast(0).toLong()
        try {
            engine.listen(m, limitMs.toInt(), object : RecognitionListener {
                override fun onPartialResult(h: String?) {
                    if (id != sessionId) return
                    val t = parseJson(h, "partial")
                    if (t.isNotEmpty()) {
                        lastPartial = t
                        cancelFinalizer()   // the user is still speaking
                        AssistantState.heard.value = collected()
                    }
                }
                override fun onResult(h: String?) {
                    if (id != sessionId) return
                    val t = parseJson(h, "text")
                    if (t.isEmpty()) return
                    segments.add(t)
                    lastPartial = ""
                    AssistantState.heard.value = collected()
                    val c = collected()
                    val quick = c.split(" ").size <= 3 && CommandParser.parse(c).let { it is Cmd.Yes || it is Cmd.No || it is Cmd.Stop || it is Cmd.Done }
                    if (quick || extraPause == 0L) finishNow()
                    else {
                        cancelFinalizer()
                        val r = Runnable { finalizer = null; finishNow() }
                        finalizer = r
                        main.postDelayed(r, extraPause)
                    }
                }
                override fun onFinalResult(h: String?) {
                    if (id != sessionId) return
                    val t = parseJson(h, "text")
                    if (t.isNotEmpty()) { segments.add(t); lastPartial = "" }
                    finishNow()
                }
                override fun onError(e: Exception?) { if (id == sessionId) fail("Mic error: ${e?.message}") }
                override fun onTimeout() { if (id == sessionId) finishNow() }
            })
        } catch (e: Exception) { fail("Microphone shuru nahi hua: ${e.message}") }
    }

    // ---- accuracy / accidental-command protection ----

    /** Of the recogniser's alternatives, prefer the first one that is a real command (helps with accents and noise). */
    private fun bestAlternative(alts: List<String>): String {
        val first = alts.first()
        fun isCommand(s: String) = CommandParser.parse(s).let { it !is Cmd.Chat && it !is Cmd.Unknown }
        if (isCommand(first)) return first
        return alts.drop(1).firstOrNull { isCommand(it) } ?: first
    }

    /** False = ignore this result (too uncertain for the chosen sensitivity). Answers to a question just asked are always accepted. */
    private fun accept(text: String, confidence: Float, p: Prefs): Boolean {
        if (dispatcher.expectsFollowUp) return true
        val known = CommandParser.parse(text).let { it !is Cmd.Chat && it !is Cmd.Unknown }
        if (known) return true
        var minConf = when (p.sensitivity) { Level.LOW -> 0.6f; Level.MEDIUM -> 0.3f; Level.HIGH -> 0f }
        if (p.noiseMode == NoiseMode.NOISY) minConf += 0.15f
        if (confidence > 0f && confidence < minConf) return false
        val words = text.trim().split(Regex("\\s+")).size
        val minWords = if (p.sensitivity == Level.LOW || p.noiseMode == NoiseMode.NOISY) 2 else 1
        return words >= minWords
    }

    private fun acceptResult(top: String, alts: List<String>, confidence: Float) {
        if (top.isEmpty() || handled.get()) return
        val p = prefs()
        val text = if (alts.size > 1 && confidence < 0.85f) bestAlternative(alts) else top
        if (!accept(text, confidence, p)) {
            sessionId++
            engine.stop()
            online.cancel()
            AssistantState.heard.value = text
            AssistantState.response.value = "Awaaz saaf nahi thi, isliye ignore kiya."
            resume()
            return
        }
        handleText(text)
    }

    /** Recognition cannot run right now: say so once, then return to wake-wait (or end a push-to-talk session). No retry loop. */
    private fun recognitionUnavailable(message: String) {
        if (!running) return
        sessionId++
        cancelFinalizer()
        engine.stop()
        online.cancel()
        val p = prefs()
        AssistantState.error.value = message
        AssistantState.response.value = message
        AssistantState.responseSource.value = "LOCAL"
        val now = System.currentTimeMillis()
        val repeated = message == lastErrorSpoken && now - lastErrorAt < 60_000L
        lastErrorSpoken = message
        lastErrorAt = now
        if (repeated || !p.voiceReplies) { resume(); return }   // never nag with the same spoken error
        AssistantState.state.value = VoiceState.SPEAKING
        tts.speak(message, p.ttsLang, ttsOpts(p)) { if (running) resume() }
    }

    private fun handleText(text: String) {
        if (text.isEmpty() || !handled.compareAndSet(false, true)) return   // never execute a command twice
        sessionId++
        cancelFinalizer()
        engine.stop()
        online.cancel()
        val p = prefs()
        val who = p.userName.ifBlank { "boss" }
        AssistantState.state.value = VoiceState.PROCESSING
        AssistantState.heard.value = text
        AssistantState.lastCommand.value = text
        AssistantState.lastStatus.value = "ACTION_STARTED"
        if (p.feedbackMode != FeedbackMode.OFF) {
            AssistantState.response.value = "Samajh raha hoon..."
            AssistantState.responseSource.value = "LOCAL"
        }
        ackJob?.cancel()
        if (p.feedbackMode == FeedbackMode.SPOKEN && p.voiceReplies) {
            // only for slow commands: if nothing has finished after 1.5 s, say so
            ackJob = scope.launch {
                delay(1500)
                if (running && AssistantState.state.value == VoiceState.PROCESSING) tts.speak("Ek second $who.", p.ttsLang, ttsOpts(p)) {}
            }
        }
        val turnSnapshot = turns.toList()
        scope.launch {
            // chained steps are only split when nothing is pending an answer
            val cmds = if (dispatcher.expectsFollowUp) listOf(CommandParser.parse(text)) else CommandParser.parseMulti(text)
            val result = try {
                // contacts lookup, app queries and accessibility waits must not run on the main thread
                withContext(Dispatchers.IO) { dispatcher.dispatchAll(cmds, turnSnapshot, text) }
            } catch (t: Throwable) {
                CommandResult(false, "Kuch gadbad ho gayi: ${t.message}")
            }
            ackJob?.cancel()
            AssistantState.lastStatus.value = result.status.name
            if (!running) return@launch
            app.history.add(HistoryItem(System.currentTimeMillis(), text, result.message, result.source, result.success))
            val cap = if (p.keepContext) prefs().aiContextTurns else 0
            if (cap > 0) {
                turns.addLast(text to result.message)
                while (turns.size > cap) turns.removeFirst()
            } else turns.clear()
            reply(result, cmds)
        }
    }

    private fun isAction(c: Cmd) = c is Cmd.OpenApp || c is Cmd.WebSearch || c is Cmd.YouTubeSearch || c is Cmd.OpenSettings ||
        c is Cmd.Swipe || c is Cmd.Volume || c is Cmd.Torch || c is Cmd.Scroll || c is Cmd.TypeText || c is Cmd.Back ||
        c is Cmd.Home || c is Cmd.Recents || c is Cmd.Refresh || c is Cmd.ClearText || c is Cmd.Submit || c is Cmd.Lock ||
        c is Cmd.WhatsAppOpenChat

    /** Voice replies / completion announcements / WhatsApp error speech from Settings. Questions and confirmations are always spoken. */
    private fun shouldSpeak(r: CommandResult, cmds: List<Cmd>, p: Prefs): Boolean {
        if (!p.voiceReplies) return false
        if (!r.success && dispatcher.lastWasWhatsApp && !p.waErrorSpoken) return false
        if (!p.announceDone && r.success && r.status == ActionStatus.ACTION_SUCCESS && !r.requiresConfirmation &&
            r.followUp == null && !r.endsTask && !dispatcher.wantsNextStep && cmds.any { isAction(it) || it is Cmd.Yes }) return false
        return true
    }

    private fun reply(r: CommandResult, cmds: List<Cmd>) {
        val p = prefs()
        AssistantState.response.value = r.message
        AssistantState.responseSource.value = r.source
        if (!shouldSpeak(r, cmds, p)) { afterReply(r, p); return }
        AssistantState.state.value = VoiceState.SPEAKING
        tts.speak(r.message, p.ttsLang, ttsOpts(p)) { afterReply(r, p) }
    }

    /** What happens after a reply: keep listening for an answer / next step, or go back to idle. */
    private fun afterReply(r: CommandResult, p: Prefs) {
        if (!running) return
        when {
            r.stopSession -> shutdown(VoiceState.STOPPED)
            dispatcher.expectsFollowUp -> { conversationWindow = false; listenCommand() }   // yes/no or the requested answer: always
            dispatcher.wantsNextStep && p.autoListen != AutoListen.NEVER -> { conversationWindow = true; listenCommand() }
            !r.endsTask && p.autoListen == AutoListen.AFTER_EVERY_COMMAND -> { conversationWindow = true; listenCommand() }
            else -> { conversationWindow = false; resume() }
        }
    }

    /** SPEAK -> RESUME LISTENING. Push-to-talk sessions end after one command; wake sessions return to wake-wait (or end if continuous listening is off). */
    private fun resume() {
        if (!running) return
        if (wakeMode && prefs().continuousListening) enterWake() else shutdown(VoiceState.STOPPED)
    }
}
