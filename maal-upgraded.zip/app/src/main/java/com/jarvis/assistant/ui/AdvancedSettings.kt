package com.jarvis.assistant.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.data.*

/** Compact option row (2-3 short labels). */
@Composable
internal fun <T> ChoiceRow(title: String, options: List<Pair<String, T>>, selected: T, onPick: (T) -> Unit) {
    HudText(title, size = 10.sp, color = Hud.Sub)
    Spacer(Modifier.height(4.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (label, v) -> HudChip(label, selected == v) { onPick(v) } }
    }
    Spacer(Modifier.height(8.dp))
}

/** Option list for long labels. */
@Composable
internal fun <T> ChoiceColumn(title: String, options: List<Pair<String, T>>, selected: T, onPick: (T) -> Unit) {
    HudText(title, size = 10.sp, color = Hud.Sub)
    Spacer(Modifier.height(4.dp))
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { (label, v) -> HudChip(label, selected == v) { onPick(v) } }
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
internal fun SwitchRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        HudText(label, modifier = Modifier.weight(1f), size = 13.sp)
        Switch(checked, onChange, enabled = enabled)
    }
}

@Composable
internal fun IntSliderRow(label: String, value: Int, range: IntRange, unit: String, onDone: (Int) -> Unit) {
    var v by remember(value) { mutableFloatStateOf(value.toFloat()) }
    HudText("$label  ${v.toInt()}$unit", size = 10.sp, color = Hud.Sub)
    Slider(value = v, onValueChange = { v = it },
        valueRange = range.first.toFloat()..range.last.toFloat(), onValueChangeFinished = { onDone(v.toInt()) })
}

@Composable
private fun Hint(text: String) {
    HudText(text, size = 11.sp, color = Hud.Sub)
    Spacer(Modifier.height(10.dp))
}

/** Voice, AI performance, WhatsApp and assistant-behaviour controls. Every value is read by the voice/command code. */
@Composable
fun AdvancedSettings() {
    val app = LocalContext.current.applicationContext as JarvisApp
    val prefs by app.settings.prefs.collectAsStateWithLifecycle()
    fun upd(t: (Prefs) -> Prefs) = app.settings.update(t)
    val lv = listOf("LOW" to Level.LOW, "MEDIUM" to Level.MEDIUM, "HIGH" to Level.HIGH)

    HudPanel("VOICE CONTROLS") {
        ChoiceRow("VOICE SENSITIVITY", lv, prefs.sensitivity) { v -> upd { it.copy(sensitivity = v) } }
        Hint("HIGH: halki ya chhoti awaaz bhi le leta hai. LOW: kam-bharosemand ya akeli awaaz ignore karta hai (galat command kam).")
        IntSliderRow("LISTENING TIMEOUT", prefs.listenTimeoutSec, 5..30, " s") { v -> upd { it.copy(listenTimeoutSec = v) } }
        Hint("Ek command ke liye sabse zyada sunne ka time.")
        ChoiceRow("PAUSE TOLERANCE", listOf("SHORT" to PauseMode.SHORT, "NORMAL" to PauseMode.NORMAL, "LONG" to PauseMode.LONG), prefs.pauseMode) { v -> upd { it.copy(pauseMode = v) } }
        Hint("Bolte waqt rukne par command kab khatam mane. LONG: lambi pause tak intezaar. (Online recogniser ise sirf hint ki tarah leta hai.)")
        ChoiceRow("NOISE HANDLING", listOf("NORMAL" to NoiseMode.NORMAL, "NOISY PLACE" to NoiseMode.NOISY), prefs.noiseMode) { v -> upd { it.copy(noiseMode = v) } }
        Hint("NOISY: zyada alternatives check karta hai aur kam-bharosemand ya ek-shabd wali awaaz ignore karta hai. Microphone noise-cancel Android ke haath mein hai.")
        ChoiceRow("WAKE WORD SENSITIVITY", lv, prefs.wakeSensitivity) { v -> upd { it.copy(wakeSensitivity = v) } }
        Hint("HIGH: milte-julte shabd bhi wake maanta hai. LOW: sirf poora phrase.")
        SwitchRow("CONTINUOUS LISTENING", prefs.continuousListening) { on -> upd { it.copy(continuousListening = on) } }
        Hint("ON: command ke baad wake word sunna jaari. OFF: ek command ke baad session band (battery bachat).")
    }

    HudPanel("AI PERFORMANCE") {
        SwitchRow("FAST RESPONSE MODE", prefs.fastMode) { on -> upd { it.copy(fastMode = on) } }
        Hint("Chhota jawab, kam wait time. Sirf unknown commands par AI use hota hai.")
        ChoiceRow("RESPONSE QUALITY", listOf("FAST" to AiQuality.FAST, "BALANCED" to AiQuality.BALANCED, "BEST" to AiQuality.BEST), prefs.aiQuality) { v -> upd { it.copy(aiQuality = v) } }
        ChoiceRow("RESPONSE LENGTH", listOf("SHORT" to RespLength.SHORT, "MEDIUM" to RespLength.MEDIUM, "LONG" to RespLength.DETAILED), prefs.respLength) { v -> upd { it.copy(respLength = v) } }
        ChoiceRow("CONTEXT RETENTION (TURNS)", listOf("0" to 0, "2" to 2, "4" to 4, "8" to 8), prefs.aiContextTurns) { v -> upd { it.copy(aiContextTurns = v) } }
        Hint("AI ko pichli kitni baatein bhejni hain.")
        ChoiceRow("PROCESSING FEEDBACK", listOf("OFF" to FeedbackMode.OFF, "SCREEN" to FeedbackMode.SCREEN, "VOICE" to FeedbackMode.SPOKEN), prefs.feedbackMode) { v -> upd { it.copy(feedbackMode = v) } }
        Hint("SCREEN: kaam ka progress dikhata hai. VOICE: dair lagne par 'Ek second' bolta hai.")
    }

    HudPanel("WHATSAPP") {
        SwitchRow("WHATSAPP INTEGRATION", prefs.waEnabled) { on -> upd { it.copy(waEnabled = on) } }
        Hint("OFF karne par WhatsApp message/chat commands band.")
        ChoiceRow("CONTACT MATCHING", listOf("STRICT" to MatchMode.STRICT, "SMART" to MatchMode.SMART), prefs.matchMode) { v -> upd { it.copy(matchMode = v) } }
        Hint("STRICT: naam bilkul sahi. SMART: galat spelling / milti-julti awaaz bhi match.")
        ChoiceRow("DEFAULT BEHAVIOUR", listOf("PREPARE ONLY" to WaSendMode.PREPARE_ONLY, "SEND AFTER YES" to WaSendMode.AUTO_SEND), prefs.waSendMode) { v -> upd { it.copy(waSendMode = v) } }
        Hint("PREPARE ONLY: chat khol kar message likh deta hai, Send aap dabate hain. SEND AFTER YES: aapki haan ke baad Send bhi dabata hai (Accessibility chahiye).")
        SwitchRow("ASK BEFORE PREPARING", prefs.waConfirm || prefs.waSendMode == WaSendMode.AUTO_SEND,
            enabled = prefs.waSendMode == WaSendMode.PREPARE_ONLY) { on -> upd { it.copy(waConfirm = on) } }
        Hint("Send karne se pehle confirmation hamesha rahegi. Sirf PREPARE ONLY mein ise band kar sakte hain.")
        SwitchRow("SPEAK WHATSAPP ERRORS", prefs.waErrorSpoken) { on -> upd { it.copy(waErrorSpoken = on) } }
        Hint("OFF: WhatsApp ki galtiyan sirf screen par dikhengi.")
        var cc by remember(prefs.countryCode) { mutableStateOf(prefs.countryCode) }
        val ccOk = cc.length in 1..3 && cc.all { it.isDigit() }
        HudField(cc, { s -> cc = s.filter { c -> c.isDigit() }.take(3); if (cc.isNotEmpty()) upd { it.copy(countryCode = cc) } }, "DEFAULT COUNTRY CODE (e.g. 91)")
        if (!ccOk) HudText("1 se 3 ank chahiye", size = 11.sp, color = Hud.Bad)
        Hint("10 ank ke number ke aage lagta hai.")
    }

    HudPanel("ASSISTANT BEHAVIOUR") {
        SwitchRow("VOICE RESPONSES", prefs.voiceReplies) { on -> upd { it.copy(voiceReplies = on) } }
        Hint("OFF: jawab sirf screen par.")
        SwitchRow("TASK COMPLETION ANNOUNCEMENTS", prefs.announceDone) { on -> upd { it.copy(announceDone = on) } }
        Hint("OFF: kaam hone par bolta nahi (sawaal, confirmation aur galtiyan phir bhi bolta hai).")
        SwitchRow("CONVERSATION CONTINUITY", prefs.keepContext) { on -> upd { it.copy(keepContext = on) } }
        Hint("ON: pichli baat aur current task yaad rakhta hai.")
        SwitchRow("FOLLOW-UP COMMANDS", prefs.followUp) { on -> upd { it.copy(followUp = on) } }
        Hint("ON: 'YouTube kholo' ke baad 'Arijit Singh search karo' seedha YouTube par hota hai.")
        ChoiceColumn("AUTO-LISTENING", listOf("ONLY WHEN I MUST ANSWER" to AutoListen.NEVER, "AFTER QUESTIONS / NEXT STEP" to AutoListen.AFTER_QUESTIONS,
            "AFTER EVERY COMMAND" to AutoListen.AFTER_EVERY_COMMAND), prefs.autoListen) { v -> upd { it.copy(autoListen = v) } }
        Hint("Jawab ya confirmation chahiye to mic hamesha khulta hai.")
    }
}
