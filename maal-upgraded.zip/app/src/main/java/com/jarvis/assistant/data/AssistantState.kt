package com.jarvis.assistant.data

import kotlinx.coroutines.flow.MutableStateFlow

enum class VoiceState {
    IDLE, INITIALIZING, WAITING_FOR_WAKE_WORD, LISTENING, PROCESSING,
    AWAITING_CONFIRMATION, SPEAKING, ERROR, STOPPED
}

/** Process-wide observable state shared by the service and the UI. */
object AssistantState {
    val state = MutableStateFlow(VoiceState.IDLE)
    val heard = MutableStateFlow("")
    val response = MutableStateFlow("")
    val responseSource = MutableStateFlow("")      // "LOCAL" or "AI"
    val error = MutableStateFlow<String?>(null)
    val aiStatus = MutableStateFlow("NOT CONFIGURED")
    val downloadProgress = MutableStateFlow<Pair<String, Int>?>(null) // lang to percent
    val downloadError = MutableStateFlow<String?>(null)

    val recogEngine = MutableStateFlow("—")        // engine used for the last command: ONLINE, OFFLINE, or e.g. "OFFLINE (FALLBACK)"
    val lastCommand = MutableStateFlow("—")        // what the user last said (recognised text)
    val lastStatus = MutableStateFlow("—")         // ActionStatus name of the last command's real outcome
    val wakeTest = MutableStateFlow<String?>(null) // result text of the wake-word test

    @Volatile var appForeground = false
}
