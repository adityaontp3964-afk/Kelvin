package com.jarvis.assistant.command

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.jarvis.assistant.accessibility.AdminReceiver
import com.jarvis.assistant.accessibility.JarvisAccessibilityService

object PermissionManager {
    private fun granted(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    fun mic(c: Context) = granted(c, Manifest.permission.RECORD_AUDIO)
    fun contacts(c: Context) = granted(c, Manifest.permission.READ_CONTACTS)
    fun notifications(c: Context) =
        Build.VERSION.SDK_INT < 33 || granted(c, Manifest.permission.POST_NOTIFICATIONS)
    fun overlay(c: Context) = Settings.canDrawOverlays(c)

    fun accessibility(c: Context): Boolean {
        val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(c, JarvisAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, true) }
    }

    /** True only while the accessibility service is actually connected and able to act. */
    fun accessibilityConnected(): Boolean = JarvisAccessibilityService.instance != null

    fun adminComponent(c: Context) = ComponentName(c, AdminReceiver::class.java)

    fun adminActive(c: Context): Boolean {
        val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent(c))
    }
}
