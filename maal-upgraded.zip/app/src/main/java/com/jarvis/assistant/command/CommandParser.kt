package com.jarvis.assistant.command

/** Pure-Kotlin parser (no Android dependencies) so it can be unit-tested on the JVM. */
object CommandParser {
    private val YES = setOf("haan", "han", "ha", "yes", "yeah", "ok", "okay", "confirm", "bhej do", "bhejo", "kar do",
        "send", "sure", "theek hai", "bilkul", "send it", "yes send")
    private val NO = setOf("nahi", "nahin", "no", "cancel", "mat bhej", "mat bhejo", "mat karo", "ruko", "nope")
    private val YES_START = setOf("haan", "han", "yes", "yeah", "yep", "okay", "ok", "bilkul", "sure", "theek", "sahi", "correct")
    private val YES_WORDS = YES_START + setOf("hai", "bhej", "bhejo", "do", "send", "it", "kar", "confirm", "ji", "sir")
    private val NO_START = setOf("nahi", "nahin", "no", "nope", "cancel", "ruko", "mat")
    private val NO_WORDS = NO_START + setOf("bhej", "bhejo", "karo", "kar", "thanks", "thank", "you", "it", "send")
    private val DONE = setOf("bas", "bas itna hi", "bas ho gaya", "that s all", "thats all", "that is all", "done", "ho gaya", "kaam ho gaya",
        "kaam khatam", "rehne do", "rehne de", "chhod do", "chod do", "chhodo", "leave it", "never mind", "nevermind", "bas kar")

    // typing
    private val R_DICTATE = Regex("^(?:jo(?: text| kuch| bhi)? (?:main|mai) bol\\w*(?: (?:wo|woh|vo|use|usse))? (?:type|likho|likh)\\w*|(?:type|likho|likh|typing))(?: (?:karo|kar|do|de|shuru karo))*$")
    private val R_TYPE_A = Regex("^(?:(?:search box|search bar|searchbox|text box|textbox|box|field|search) (?:mein|me|main|par|pe) )?(.+?) (?:likho|likh do|likh de|likh|type karo|type kar do|type kar)$")
    private val R_TYPE_B = Regex("^(?:likho|likh|type karo|type kar) (.+)$")
    private val R_TYPE_C = Regex("^type (?!of |a |an |the )(.+)$")
    private val SUBMIT_PHRASES = setOf("search karo", "search kar", "search kar do", "search button dabao", "enter dabao",
        "enter karo", "enter press karo", "submit", "submit karo")

    private val Y1 = Regex("^(?:search|play|dhundh\\w*|dhoondh\\w*|chala\\w*|laga\\w*) (?:for )?(.+?) (?:on |par |pe |per |me |mein )?youtube(?: .*)?$")
    private val Y3 = Regex("^(.+?) youtube (?:par|pe|per|me|mein|on) (?:search|play|chala\\w*|laga\\w*|dhundh\\w*).*$")
    private val Y2 = Regex("^youtube (?:par |pe |per |me |mein |on )?(?:search |play |dhundh\\w* )?(.+?)(?: (?:search|play|chala\\w*|laga\\w*|dhundh\\w*))?(?: (?:kar|karo|do|de))*$")

    private val S1 = Regex("^(?:search|google|dhundh\\w*|dhoondh\\w*)(?: for)? (.+?)(?: (?:kar|karo|do|de))*$")
    private val S2 = Regex("^(.+?) (?:search|google)(?: (?:kar|karo|do))*$")

    private val O1 = Regex("^(?:open|launch|start) (.+?)(?: (?:kar|karo|do|de))*$")
    private val O2 = Regex("^(.+?) (?:khol\\w*|chalu|chalao|open|start)(?: (?:kar|karo|do|de|dena))*$")

    private val OPEN_VERBS = Regex("^(khol\\w*|open|chalu|chalao|start|kar|karo|do|de)( (kar|karo|do|de))*$")

    /** The normaliser lower-cases everything; restore the user's capitalisation for text that gets typed or sent. */
    private fun restoreCase(raw: String, payload: String): String {
        val i = raw.lowercase().indexOf(payload.lowercase())
        return if (i >= 0 && i + payload.length <= raw.length) raw.substring(i, i + payload.length).trim() else payload
    }

    private fun has(t: String, vararg words: String) = words.any { " $t ".contains(" $it ") }

    fun parse(raw: String): Cmd {
        if (raw.isBlank()) return Cmd.Unknown(raw)
        val t = Normalizer.normalize(raw)
        if (t.isBlank()) return Cmd.Greeting
        if (t in YES) return Cmd.Yes
        if (t in NO) return Cmd.No
        val words = t.split(" ")
        if (words.size <= 3 && words[0] in NO_START && words.all { it in NO_WORDS }) return Cmd.No
        if (words.size <= 3 && words[0] in YES_START && words.all { it in YES_WORDS }) return Cmd.Yes
        if (t in DONE) return Cmd.Done

        // WhatsApp message / chat commands (before Stop/typing so a message like "bye" or "likho" is never mistaken for a command)
        WhatsAppParser.parseOpenChat(raw)?.let { return it }
        WhatsAppParser.parse(raw)?.let { return it }

        if (t == "band karo" || has(t, "stop", "stop listening", "bye", "good bye", "alvida", "band ho ja")) return Cmd.Stop

        // Typing / dictation (before the WhatsApp block so "message likho" style text is not mistaken for a send)
        if (R_DICTATE.matches(t)) return Cmd.Dictate
        (R_TYPE_A.find(t) ?: R_TYPE_B.find(t) ?: R_TYPE_C.find(t))?.let {
            val payload = it.groupValues[1].trim()
            if (payload.isNotEmpty()) return Cmd.TypeText(restoreCase(raw, payload))
        }
        if (t in SUBMIT_PHRASES) return Cmd.Submit

        if (has(t, "recent apps", "recent app", "recents", "recent screen", "task switcher")) return Cmd.Recents
        if (has(t, "scroll", "scrol", "skroll")) {
            val down = has(t, "neeche", "niche", "nichey", "nechay", "down")
            val up = has(t, "upar", "oopar", "upper", "up")
            if (down && !up) return Cmd.Scroll(true)
            if (up && !down) return Cmd.Scroll(false)
            return Cmd.MissingArg("Upar scroll karun ya neeche?")
        }
        if (has(t, "refresh", "reload")) return Cmd.Refresh
        if (has(t, "clear", "saaf", "mita", "mitao", "hatao", "delete") && has(t, "text", "likha", "box")) return Cmd.ClearText

        if (has(t, "lock") || t.contains("screen band") || t.contains("phone band")) return Cmd.Lock
        if (has(t, "next reel", "next video", "next short", "swipe up", "reel badlo", "agli reel")) return Cmd.Swipe(true)
        if (has(t, "previous reel", "previous video", "pichli reel", "swipe down")) return Cmd.Swipe(false)
        if (has(t, "go home", "home screen", "home jao")) return Cmd.Home
        if (has(t, "go back", "back jao", "peeche jao", "piche jao", "back kar")) return Cmd.Back

        // Volume (before the settings block so "volume badhao" changes volume while "volume settings kholo" opens settings)
        if (has(t, "volume", "awaaz", "sound") && !has(t, "settings", "setting", "khol", "kholo", "open")) {
            when {
                has(t, "mute", "silent") -> return Cmd.Volume(0)
                has(t, "badhao", "badha", "badhana", "increase", "up", "zyada", "tez", "louder") -> return Cmd.Volume(1)
                has(t, "kam", "ghatao", "ghata", "ghatana", "decrease", "down", "low", "dheere", "halka") -> return Cmd.Volume(-1)
            }
        }

        // Torch / flashlight
        if (has(t, "torch", "flashlight")) {
            return when {
                has(t, "off", "band", "bujhao", "bandh") -> Cmd.Torch(false)
                has(t, "on", "chalu", "jalao", "chalao", "start") -> Cmd.Torch(true)
                else -> Cmd.MissingArg("Torch on karun ya off?")
            }
        }

        // Settings screens
        val kind = when {
            has(t, "wifi", "wi fi") -> "wifi"
            has(t, "bluetooth") -> "bluetooth"
            has(t, "display", "brightness") -> "display"
            has(t, "sound", "volume", "awaaz") -> "sound"
            has(t, "accessibility") -> "accessibility"
            else -> null
        }
        if (kind != null && has(t, "khol", "kholo", "open", "settings", "setting", "on", "off", "chalu", "band")) {
            return Cmd.OpenSettings(kind)
        }

        // YouTube
        if (has(t, "youtube")) {
            Y1.find(t)?.let { return Cmd.YouTubeSearch(it.groupValues[1].trim()) }
            Y3.find(t)?.let { return Cmd.YouTubeSearch(it.groupValues[1].trim()) }
            Y2.find(t)?.let {
                val q = it.groupValues[1].trim()
                if (!OPEN_VERBS.matches(q)) return Cmd.YouTubeSearch(q)
            }
        }

        // Web search
        if (t in setOf("search", "google", "dhundho")) return Cmd.MissingArg("Kya search karna hai?")
        S1.find(t)?.let {
            val q = it.groupValues[1].trim()
            if (!OPEN_VERBS.matches(q)) return Cmd.WebSearch(q)
        }
        S2.find(t)?.let {
            val q = it.groupValues[1].trim()
            if (!OPEN_VERBS.matches(q)) return Cmd.WebSearch(q)
        }

        // Identity
        if (has(t, "tumhara naam", "tera naam", "aapka naam", "your name", "who are you", "tum kaun ho", "aap kaun ho", "tu kaun hai")) return Cmd.AskName
        if (has(t, "mera naam", "my name", "main kaun hoon")) return Cmd.AskUserName

        // Time / date
        if (has(t, "date", "tarikh", "tareekh", "what day", "kaun sa din")) return Cmd.TellDate
        if (has(t, "time", "samay", "baje", "waqt")) return Cmd.TellTime

        // Open app
        (O1.find(t) ?: O2.find(t))?.let {
            val name = it.groupValues[1].trim().removeSuffix(" app").trim()
            if (name.isNotEmpty()) return Cmd.OpenApp(name)
        }

        if (has(t, "thanks", "thank you", "thank", "shukriya", "dhanyavad")) return Cmd.Thanks
        if (has(t, "kaise ho", "how are you", "kya haal", "kaisa hai")) return Cmd.HowAreYou
        if (has(t, "hello", "hi", "namaste", "namaskar") || t == "jarvis") return Cmd.Greeting

        return if (t.split(" ").size >= 2) Cmd.Chat(raw.trim()) else Cmd.Unknown(raw)
    }

    // ---- multi-step ("YouTube kholo aur Arijit Singh search karo") ----

    private val SPLIT = Regex("\\s+(?:aur phir|and then|then|phir|fir|uske baad|uske bad|aur|and)\\s+", RegexOption.IGNORE_CASE)

    private fun isSimple(c: Cmd) = c is Cmd.OpenApp || c is Cmd.YouTubeSearch || c is Cmd.WebSearch || c is Cmd.Scroll ||
        c is Cmd.Back || c is Cmd.Home || c is Cmd.Recents || c is Cmd.Volume || c is Cmd.Torch || c is Cmd.OpenSettings ||
        c is Cmd.Swipe || c is Cmd.Refresh || c is Cmd.Submit || c is Cmd.ClearText || c is Cmd.TypeText

    /**
     * Splits a chained instruction into steps. It only splits when EVERY part is a complete, simple command, so message
     * text, typed text and search queries containing "aur"/"and" are never cut up. WhatsApp commands are never split.
     */
    fun parseMulti(raw: String): List<Cmd> {
        val single = parse(raw)
        if (single is Cmd.WhatsApp || single is Cmd.WhatsAppToContext || single is Cmd.WhatsAppOpenChat || single is Cmd.TypeText) return listOf(single)
        val parts = raw.trim().split(SPLIT).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size < 2 || parts.size > 4) return listOf(single)
        val cmds = parts.map { parse(it) }
        return if (cmds.all { isSimple(it) }) cmds else listOf(single)
    }

    private val PLAY_A = Regex("^(?:play|chalao|chala do|laga do|lagao|bajao)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val PLAY_B = Regex("^(.+?)\\s+(?:chalao|chala do|chalado|laga do|lagao|bajao|play kar\\w*|sunao|suna do)$", RegexOption.IGNORE_CASE)

    /** "play Arijit Singh", "Arijit Singh ke gaane chalao": the thing to play, with the user's own spelling. Null if not a play request. */
    fun playQuery(raw: String): String? {
        val text = raw.trim()
        val q = (PLAY_A.find(text) ?: PLAY_B.find(text))?.groupValues?.get(1)?.trim() ?: return null
        return q.takeIf { it.isNotEmpty() }
    }
}
