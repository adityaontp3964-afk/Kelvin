package com.jarvis.assistant.command

import com.jarvis.assistant.data.DEFAULT_WAKE_PHRASE
import com.jarvis.assistant.data.Level

/**
 * Text-based wake phrase matching on top of continuous Vosk recognition.
 * This is NOT a dedicated wake-word engine: it is ordinary speech recognition whose output is compared to the phrase.
 * Any phrase can be saved, but it is only detected if the Vosk model recognises its words (use the wake-word test).
 *
 * Sensitivity: LOW needs the exact phrase (fewest false activations), MEDIUM also accepts known mis-hearings of the
 * last word, HIGH additionally accepts words that are one or two letters off.
 */
object WakeMatcher {
    /** Common mis-hearings of built-in names, keyed by the last word of the wake phrase. */
    private val aliasGroups = mapOf(
        "friday" to listOf("friday", "fry day", "fri day", "frieday", "fraiday", "freiday", "फ्राइडे", "फ्राईडे"),
        "jarvis" to listOf("jarvis", "jar vis", "jarvas", "jarvish", "jarves", "jarwis", "javis", "जार्विस", "जारविस")
    )

    /** Returns null if [phrase] is acceptable as a wake phrase, otherwise a short reason. */
    fun validate(phrase: String): String? {
        val p = phrase.trim()
        if (p.length < 3) return "Kam se kam 3 akshar chahiye"
        if (p.split(Regex("\\s+")).size > 4) return "Zyada se zyada 4 shabd"
        if (!p.all { it.isLetter() || it.isWhitespace() }) return "Sirf akshar aur space (koi number/symbol nahi)"
        return null
    }

    private fun distance(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    fun matches(text: String, phrase: String, sensitivity: Level = Level.MEDIUM): Boolean {
        val t = text.lowercase().trim()
        if (t.isEmpty()) return false
        val p = phrase.lowercase().trim().ifEmpty { DEFAULT_WAKE_PHRASE }
        if (t.contains(p)) return true
        if (sensitivity == Level.LOW) return false
        val key = p.split(" ").last()
        aliasGroups[key]?.let { group -> if (group.any { t.contains(it) }) return true }
        if (sensitivity == Level.MEDIUM) return aliasGroups[key] == null && key.length >= 4 && t.contains(key)
        // HIGH: a heard word that is a close misspelling of the last word of the phrase
        if (key.length >= 5) {
            val allowed = if (key.length >= 7) 2 else 1
            if (t.split(" ").any { it.length >= 4 && distance(it, key) <= allowed }) return true
        }
        return key.length >= 4 && t.contains(key)
    }
}
