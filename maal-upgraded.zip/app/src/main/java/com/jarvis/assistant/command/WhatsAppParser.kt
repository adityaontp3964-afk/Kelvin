package com.jarvis.assistant.command

/**
 * Understands natural WhatsApp phrases in Hindi, Hinglish and English WITHOUT altering the user's words.
 *
 * Matching is done on cleaned lower-case tokens, but the contact name and message text are cut out of the ORIGINAL
 * tokens, so case, punctuation, emoji and filler words ("bhai", "yaar", "please") inside the message are preserved.
 * (The old parser matched on the normalised string, which lower-cased the message and dropped such words.)
 *
 * Pure Kotlin (no Android dependencies) so it can be unit-tested on the JVM.
 */
object WhatsAppParser {
    private val KO = setOf("ko", "को")
    private val MSG = setOf("message", "msg", "sandesh", "massage", "मैसेज", "मेसेज", "संदेश")
    private val WA = setOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वाट्सऐप", "व्हॉट्सऐप")
    private val POST = setOf("par", "pe", "per", "me", "mein", "main", "on", "पर", "में")
    private val LEAD = setOf("please", "pls", "plz", "hey", "friday", "jarvis", "arre", "are", "ek", "zara", "sir", "boss")
    private val PRON = setOf("usko", "use", "usse", "unko", "unhe", "isko", "ise", "उसको", "उसे")
    private val STEMS = setOf("bhej", "send", "kar", "likh", "भेज")
    private val AUX2 = setOf("do", "de", "dena", "dedo", "hai", "hain", "chahiye", "hoga", "दो", "दे")
    private val TELL = setOf("bolo", "bol", "bolna", "bata", "batao", "batana", "keh", "kaho", "kehna", "likh", "likho", "likhna",
        "बोलो", "बता", "बताओ", "कहो", "लिखो")
    private val CONJ = setOf("ki", "ke", "that", "ke ki", "कि")
    private val TAIL_VERBS = setOf("do", "de", "dena", "dedo", "karo", "kar", "karna", "hai", "chahiye", "dijiye", "kijiye", "दो", "दे")
    private val SEPARATORS = setOf("saying", "that", "ki", "ke", "colon", "कि")
    private val NOT_NAMES = setOf("kya", "aaya", "aayi", "padho", "dikhao", "check", "read", "open", "kholo", "khol", "mera", "meri",
        "mere", "new", "last", "show", "dekho", "sunao", "ka", "ki", "ke", "chalu", "chalao", "start", "launch", "band", "close",
        "kar", "karo", "dikha", "chat", "chats", "status", "web", "call", "video", "business", "kholna", "khulao")

    private fun clean(tok: String): String {
        var s = tok.lowercase()
        var a = 0
        var b = s.length
        while (a < b && !(s[a].isLetterOrDigit() || Character.getType(s[a]) == Character.NON_SPACING_MARK.toInt() ||
                Character.getType(s[a]) == Character.COMBINING_SPACING_MARK.toInt())) a++
        while (b > a && !(s[b - 1].isLetterOrDigit() || Character.getType(s[b - 1]) == Character.NON_SPACING_MARK.toInt() ||
                Character.getType(s[b - 1]) == Character.COMBINING_SPACING_MARK.toInt())) b--
        s = s.substring(a, b)
        return s
    }

    private fun isStrictSend(t: String) = t.startsWith("bhej") || t == "send" || t.startsWith("भेज") || t == "sends"
    private fun isVerb(t: String) = isStrictSend(t) || t.startsWith("kar") || t in AUX2 || t.startsWith("likh") || t.startsWith("dijiye")
    private fun needsAux(t: String) = t in STEMS || t.endsWith("na")

    private class Matched(val text: String?)

    private fun join(r: List<String>, from: Int, to: Int): String = r.subList(from, to).joinToString(" ").trim()

    /** Parses what follows "<name> ko" (or "usko"). Returns null if it is not a message instruction. */
    private fun afterKo(r: List<String>, n: List<String>, from: Int): Matched? {
        var i = from
        var sawWa = false
        if (i < n.size && n[i] in WA) { sawWa = true; i++; if (i < n.size && n[i] in POST) i++ }
        if (i < n.size && n[i] == "ek") i++
        if (i >= n.size) return null

        // A: "message bhejo <text>"
        if (n[i] in MSG) {
            var j = i + 1
            if (j < n.size && isVerb(n[j])) {
                val first = n[j]
                j++
                if (j < n.size && needsAux(first) && n[j] in AUX2) j++
            }
            return if (j >= n.size) Matched(null) else Matched(join(r, j, r.size))
        }
        // C: "bolo ki <text>", "bhejo <text>", "whatsapp karo <text>"
        if (n[i] in TELL || isStrictSend(n[i]) || (sawWa && n[i].startsWith("kar"))) {
            var j = i + 1
            if (j < n.size && n[j] in setOf("do", "de", "dena", "dedo", "दो", "दे")) j++
            if (j < n.size && n[j] in CONJ) j++
            return if (j >= n.size) Matched(null) else Matched(join(r, j, r.size))
        }
        // D: "<text> message bhejo", "<text> bhej do"
        var e = n.size
        var strict = false
        while (e > i && (isStrictSend(n[e - 1]) || n[e - 1] in TAIL_VERBS)) { if (isStrictSend(n[e - 1])) strict = true; e-- }
        var sawMsg = false
        if (e > i && n[e - 1] in MSG) { sawMsg = true; e-- }
        if (!strict && !sawMsg) return null
        return if (e <= i) Matched(null) else Matched(join(r, i, e))
    }

    /** Returns a WhatsApp command for [raw], or null if [raw] is not a message instruction. */
    fun parse(raw: String): Cmd? {
        val rAll = raw.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (rAll.isEmpty()) return null
        val nAll = rAll.map { clean(it) }
        var s = 0
        while (s < nAll.size && nAll[s] in LEAD) s++
        val r = rAll.drop(s)
        val n = nAll.drop(s)
        if (n.isEmpty()) return null
        if (!(n.any { it in MSG || it in WA || it in KO || it in PRON } || n[0] == "tell")) return null

        // 1. pronoun follow-up: "usko hi message bhejo"
        val pronAt = when {
            n[0] in PRON -> 1
            n.size > 1 && n[0] == "us" && n[1] == "ko" -> 2
            else -> -1
        }
        if (pronAt >= 0) {
            val m = afterKo(r, n, pronAt) ?: return null
            val t = m.text
            return if (t.isNullOrBlank() || t == "ek") Cmd.WhatsAppToContext(null) else Cmd.WhatsAppToContext(t)
        }

        // 2. "<name> ko ...": "rahul sharma ko message bhejo hello", "rahul ko hello bhej do", "rahul ko bolo ki ..."
        val k = (1 until minOf(n.size, 6)).firstOrNull { n[it] in KO }
        if (k != null && n.take(k).none { it in MSG || it in WA }) {
            val m = afterKo(r, n, k + 1)
            if (m != null) {
                val name = join(r, 0, k)
                val t = m.text
                return if (t.isNullOrBlank()) Cmd.MissingArg("Kya message bhejna hai?") else Cmd.WhatsApp(name, t)
            }
        }

        // 3. leading forms: "send message to X ...", "message bhejo X ko ...", "tell X that ...", "whatsapp X ...", "message X ..."
        var i = 0
        var triggered = false
        if (n[i] == "send" || n[i] == "write" || n[i] == "drop" || n[i] == "text") { i++; triggered = true }
        while (i < n.size && n[i] in setOf("a", "an", "the", "ek", "one")) i++
        if (i < n.size && n[i] in WA) { i++; triggered = true; if (i < n.size && n[i] in POST) i++ }
        if (i < n.size && n[i] in MSG) { i++; triggered = true }
        else if (i < n.size && n[0] == "tell") { i = 1; triggered = true }
        if (!triggered) return fallback(n)
        // Hindi order: "message bhejo X ko <text>"
        var verbs = 0
        while (i < n.size && verbs < 2 && (isStrictSend(n[i]) || (verbs == 1 && n[i] in AUX2))) { i++; verbs++ }
        if (i < n.size && (n[i] == "to" || n[i] == "for")) i++
        if (i >= n.size) return fallback(n)
        if (n[i] in NOT_NAMES) return null
        val koAt = (i until n.size).firstOrNull { n[it] in KO }
        if (koAt != null && koAt > i && koAt - i <= 4) {
            val t = if (koAt + 1 < n.size) join(r, koAt + 1, r.size) else ""
            return if (t.isBlank()) Cmd.MissingArg("Kya message bhejna hai?") else Cmd.WhatsApp(join(r, i, koAt), t)
        }
        // explicit separator: "to rahul saying hello"
        val sepAt = (i + 1 until n.size).firstOrNull { n[it] in SEPARATORS && it - i <= 4 }
        if (sepAt != null) {
            val t = if (sepAt + 1 < n.size) join(r, sepAt + 1, r.size) else ""
            return if (t.isBlank()) Cmd.MissingArg("Kya message bhejna hai?") else Cmd.WhatsApp(join(r, i, sepAt), t)
        }
        if (n.size - i < 2) return Cmd.MissingArg("Kya message bhejna hai?")
        // name and text are not separated: first word for now, the dispatcher re-splits using the contact list
        val cmd = Cmd.WhatsApp(r[i], join(r, i + 1, r.size))
        cmd.splitSource = join(r, i, r.size)
        return cmd
    }

    private fun fallback(n: List<String>): Cmd? {
        val hasMsg = n.any { it in MSG }
        if (hasMsg && (n.any { isStrictSend(it) } || n.any { it in KO })) return Cmd.MissingArg("Kisko aur kya message bhejna hai?")
        return null
    }

    /** "Kartavya ki chat kholo", "WhatsApp mein Rahul Sharma ki chat open karo", "open chat with Rahul". */
    fun parseOpenChat(raw: String): Cmd? {
        val rAll = raw.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val nAll = rAll.map { clean(it) }
        var s = 0
        while (s < nAll.size && nAll[s] in LEAD) s++
        val r = rAll.drop(s)
        val n = nAll.drop(s)
        val c = n.indexOf("chat")
        if (c < 0) return null
        var a = 0
        if (a < n.size && n[a] in WA) { a++; if (a < n.size && n[a] in POST) a++ }
        // "open chat with X"
        if (n.size > c + 2 && n[c + 1] == "with" && n.take(c).all { it in setOf("open", "start") || it in WA || it in POST }) {
            val withName = join(r, c + 2, r.size)
            return if (withName.isBlank()) null else Cmd.WhatsAppOpenChat(withName)
        }
        // "X ki chat kholo": the name must be at least one word between the optional WhatsApp prefix and "ki/ka/ke chat"
        if (c - 1 <= a || n[c - 1] !in setOf("ki", "ka", "ke")) return null
        val name = join(r, a, c - 1)
        if (name.isBlank()) return null
        val tail = n.drop(c + 1)
        val openWords = setOf("khol", "kholo", "kholna", "open", "start", "dikhao", "kar", "karo", "do", "de", "dena", "khulao")
        if (tail.isEmpty() || !tail.all { it in openWords }) return null
        return Cmd.WhatsAppOpenChat(name)
    }
}
