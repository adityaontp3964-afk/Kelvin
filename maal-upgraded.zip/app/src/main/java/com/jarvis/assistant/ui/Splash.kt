package com.jarvis.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SplashScreen(status: String, step: Int, total: Int) {
    val progress by animateFloatAsState(step.toFloat() / total, tween(400), label = "boot")
    val inf = rememberInfiniteTransition(label = "spin")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "spin")
    Column(
        Modifier.fillMaxSize().background(Hud.Bg).padding(32.dp)
            .semantics { contentDescription = "FRIDAY starting. $status" },
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HudText("F.R.I.D.A.Y", size = 40.sp, color = Hud.Cyan, spacing = 4.sp, weight = FontWeight.Bold, glow = true)
        Spacer(Modifier.height(8.dp))
        HudText("VOICE ASSISTANT", size = 10.sp, color = Hud.Sub, spacing = 2.sp, align = TextAlign.Center)
        Spacer(Modifier.height(40.dp))
        Canvas(Modifier.size(96.dp)) {
            val s = 3.dp.toPx()
            drawCircle(Hud.Dim, style = Stroke(s))
            rotate(spin) {
                drawArc(Hud.Cyan, -90f, 270f, false, Offset(s / 2, s / 2), Size(size.width - s, size.height - s), style = Stroke(s, cap = StrokeCap.Round))
            }
            drawCircle(Hud.Cyan.copy(alpha = 0.7f), radius = 3.dp.toPx())
        }
        Spacer(Modifier.height(32.dp))
        HudText(status, size = 15.sp, color = Hud.Txt, spacing = 2.sp, align = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth().widthIn(max = 420.dp).height(6.dp).border(1.dp, Hud.Dim, RoundedCornerShape(3.dp))) {
            Box(Modifier.fillMaxWidth(progress).fillMaxHeight()
                .background(Brush.horizontalGradient(listOf(Hud.Cyan, Hud.Blue)), RoundedCornerShape(3.dp)))
        }
        Spacer(Modifier.height(8.dp))
        HudText("${(progress * 100).toInt()}%", size = 11.sp, color = Hud.Sub)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 0 until total) {
                Box(Modifier.size(6.dp).background(if (i < step) Hud.Cyan else Hud.Dim, RoundedCornerShape(3.dp)))
            }
        }
    }
}
