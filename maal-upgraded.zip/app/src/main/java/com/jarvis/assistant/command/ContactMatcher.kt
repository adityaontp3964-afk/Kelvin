package com.jarvis.assistant.command

/** Pure-Kotlin phone-number helpers (unit-testable on the JVM). */
object PhoneUtil {
    /**
     * Digits for a wa.me link: international format, no '+', no leading zeros. Bare 10-digit numbers get [defaultCc].
     * Returns null if the result does not look like a phone number (8..15 digits).
     */
    fun toWaNumber(raw: String, defaultCc: String): String? {
        val trimmed = raw.trim()
        val plus = trimmed.startsWith("+")
        var d = trimmed.filter { it.isDigit() }
        if (d.isEmpty()) return null
        d = when {
            plus -> d
            d.startsWith("00") -> d.removePrefix("00")
            d.length == 10 -> defaultCc + d
            d.length == 11 && d.startsWith("0") -> defaultCc + d.substring(1)
            else -> d
        }
        return if (d.length in 8..15) d else null
    }
}

/** One phone-number row of the Android Contacts database. [type] is ContactsContract Phone.TYPE_* (2 = mobile). */
data class ContactEntry(val id: String, val name: String, val number: String, val type: Int)

data class ContactHit(val name: String, val number: String, val type: Int, val score: Int)

/**
 * Matches a spoken name against contact names. Speech recognisers misspell Indian names ("Kartaviya", "Rahool"),
 * so there is a ladder of match strengths; STRICT mode keeps only the top two (exact name / all spoken words present).
 * Pure Kotlin so it can be unit-tested.
 */
object ContactMatcher {
    fun norm(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}\\s]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Rough phonetic key for Latin-script Indian names: equal keys mean "sounds the same". */
    fun key(token: String): String {
        var s = token.lowercase()
        s = s.replace("ph", "f").replace("w", "v").replace("z", "j").replace("y", "i")
            .replace("aa", "a").replace("ee", "i").replace("ii", "i").replace("oo", "u").replace("uu", "u")
        s = s.replace(Regex("(?<=[bcdgjkpstv])h"), "")
        s = s.replace(Regex("(.)\\1"), "$1")
        return s
    }

    fun editDistance(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    private fun tokenScore(a: String, b: String): Int = when {
        a == b -> 90
        a.length >= 3 && b.startsWith(a) -> 80
        key(a) == key(b) -> 70
        a.length >= 4 && b.length >= 4 && editDistance(a, b) <= (if (a.length >= 8) 2 else 1) -> 60
        else -> 0
    }

    /** 100 exact name, 90 every spoken word is a word of the name, 80/70/60 prefix / sounds-alike / one typo; 0 = no match. */
    fun scoreName(query: String, name: String): Int {
        val q = norm(query)
        val n = norm(name)
        if (q.isEmpty() || n.isEmpty()) return 0
        if (q == n) return 100
        val qt = q.split(" ")
        val nt = n.split(" ")
        if (qt.all { it in nt }) return 90
        var worst = 90
        for (a in qt) {
            val best = nt.maxOf { tokenScore(a, it) }
            if (best == 0) return 0
            worst = minOf(worst, best)
        }
        return worst
    }

    private fun numberKey(e: ContactEntry, cc: String): String =
        PhoneUtil.toWaNumber(e.number, cc) ?: e.number.filter { it.isDigit() }

    /**
     * Best-matching contacts for [query]. Only the strongest tier is returned (an exact "Rahul" hides "Rahul Sharma").
     * A contact with several numbers yields its mobile number(s) if it has any. Duplicate name+number rows collapse.
     * More than one result means the caller must ask the user which one.
     */
    fun find(entries: List<ContactEntry>, query: String, strict: Boolean, defaultCc: String): List<ContactHit> {
        val min = if (strict) 90 else 60
        val scored = entries.map { it to scoreName(query, it.name) }.filter { it.second >= min }
        if (scored.isEmpty()) return emptyList()
        val top = scored.maxOf { it.second }
        val byContact = LinkedHashMap<String, MutableList<ContactEntry>>()
        for ((e, s) in scored) if (s == top) byContact.getOrPut(e.id) { mutableListOf() }.add(e)
        val hits = ArrayList<ContactHit>()
        for ((_, list) in byContact) {
            val distinct = list.distinctBy { numberKey(it, defaultCc) }
            val mobiles = distinct.filter { it.type == 2 }
            val use = if (distinct.size > 1 && mobiles.isNotEmpty()) mobiles else distinct
            use.forEach { hits.add(ContactHit(it.name, it.number, it.type, top)) }
        }
        return hits.distinctBy { it.name.lowercase() + "|" + (PhoneUtil.toWaNumber(it.number, defaultCc) ?: it.number) }
    }

    fun typeLabel(type: Int): String = when (type) { 1 -> "home"; 2 -> "mobile"; 3 -> "work"; else -> "number" }

    /** Spoken label of a hit: the name, plus number type and last digits when several hits share that name. */
    fun label(h: ContactHit, all: List<ContactHit>): String =
        if (all.count { it.name.equals(h.name, ignoreCase = true) } > 1)
            "${h.name} (${typeLabel(h.type)} ${h.number.filter { it.isDigit() }.takeLast(4)})"
        else h.name

    /**
     * For phrases like "message rahul sharma hello" where name and text are not separated: tries the longest leading
     * run of words that is a strong contact match. Returns (name, text) or null.
     */
    fun splitRecipient(entries: List<ContactEntry>, whole: String, strict: Boolean, defaultCc: String): Pair<String, String>? {
        val tokens = whole.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.size < 2) return null
        for (k in (tokens.size - 1) downTo 1) {
            val name = tokens.take(k).joinToString(" ")
            val hits = find(entries, name, strict, defaultCc)
            if (hits.isNotEmpty() && hits[0].score >= 90) return name to tokens.drop(k).joinToString(" ")
        }
        return null
    }
}
